/**
 * 
 */
/**
 * @author elkesj
 *
 */
module CultureAppIsrael {
	requires java.desktop;
}